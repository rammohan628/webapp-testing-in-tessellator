const { test, expect } = require('@playwright/test');
const baseURL = process.env.BASE_URL;

test.describe('Frontend UI Tests', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(baseURL); // Ensure your React app is running
  });

  test('Add a product', async ({ page }) => {
    // Wait for the page to load
    await page.waitForLoadState('load');
    
    // Click the "Add" link
    await page.click('a[href="/add"]');
    
    // Wait for the "Add Product" page to load
    await page.waitForSelector('#name');
    
    // Fill the product form
    await page.fill('#name', 'Test Product');
    await page.fill('#price', '9.99');
    
    // Submit the form
    await page.click('button[type="submit"]');
    
    // Wait for navigation to home page
    await expect(page).toHaveURL(baseURL);
    
    // Check if the product was added
    await expect(page.locator('table')).toContainText('Test Product');
  });

  test('Edit a product', async ({ page }) => {
    // Wait for the page to load
    await page.waitForLoadState('load');
    
    // Click the "Edit" link for the first product
    await page.click('a:has-text("Edit")'); // Adjust this selector if necessary
    
    // Wait for the "Edit Product" page to load
    await page.waitForSelector('#name');
    
    // Fill the product form
    await page.fill('#name', 'Updated Product');
    await page.fill('#price', '19.99');
    
    // Submit the form
    await page.click('button[type="submit"]');
    
    // Wait for navigation to home page
    await expect(page).toHaveURL(baseURL);
    
    // Check if the product was updated
    await expect(page.locator('table')).toContainText('Updated Product');
  });

  test('Delete a product', async ({ page }) => {
    // Wait for the page to load
    await page.waitForLoadState('load');
    
    // Click the "Delete" button for the first product
    await page.click('button:has-text("Delete")'); // Adjust this selector if necessary
    
    // Wait for navigation to home page
    await expect(page).toHaveURL(baseURL);
    
    // Check if the product was deleted
    await expect(page.locator('table')).not.toContainText('Updated Product');
  });
});
