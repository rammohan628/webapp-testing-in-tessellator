// client/src/components/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer className="mt-5">
      <div className="container">
        <hr />
        <p className="text-center">© 2024 CRUD App. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
