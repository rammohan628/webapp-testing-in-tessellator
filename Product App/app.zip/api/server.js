const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3001;
const ipAddress = '0.0.0.0'; // Use 0.0.0.0 to make the server accessible on all network interfaces

// Setup database
const db = new sqlite3.Database(':memory:');
db.serialize(() => {
  db.run('CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL)');
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.get('/api/products', (req, res) => {
  db.all('SELECT * FROM products', (err, rows) => {
    if (err) {
      console.error('Error retrieving products:', err.message);
      return res.status(500).send('Database error');
    }
    res.json(rows);
  });
});

app.get('/api/products/:id', (req, res) => {
  const id = req.params.id;
  db.get('SELECT * FROM products WHERE id = ?', [id], (err, row) => {
    if (err) {
      console.error('Error retrieving product:', err.message);
      return res.status(500).send('Database error');
    }
    if (!row) {
      return res.status(404).send('Product not found');
    }
    res.json(row);
  });
});

app.post('/api/products', (req, res) => {
  const { name, price } = req.body;
  if (!name || !price) {
    return res.status(400).send('Name and price are required');
  }

  db.run('INSERT INTO products (name, price) VALUES (?, ?)', [name, price], function(err) {
    if (err) {
      console.error('Error adding product:', err.message);
      return res.status(500).send('Failed to add product');
    }
    res.status(201).json({ id: this.lastID });
  });
});

app.put('/api/products/:id', (req, res) => {
  const id = req.params.id;
  const { name, price } = req.body;
  if (!name || !price) {
    return res.status(400).send('Name and price are required');
  }

  db.run('UPDATE products SET name = ?, price = ? WHERE id = ?', [name, price, id], (err) => {
    if (err) {
      console.error('Error updating product:', err.message);
      return res.status(500).send('Failed to update product');
    }
    res.status(200).send('Product updated successfully');
  });
});

app.delete('/api/products/:id', (req, res) => {
  const id = req.params.id;

  db.run('DELETE FROM products WHERE id = ?', [id], (err) => {
    if (err) {
      console.error('Error deleting product:', err.message);
      return res.status(500).send('Failed to delete product');
    }
    res.status(200).send('Product deleted successfully');
  });
});

// Start server
app.listen(port, ipAddress, () => {
  console.log(`Backend API running on http://${ipAddress}:${port}`);
});
