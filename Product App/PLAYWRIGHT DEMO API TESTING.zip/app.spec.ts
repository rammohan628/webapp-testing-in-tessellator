const { test, expect } = require('@playwright/test');

const baseURL = process.env.BASE_URL;

test.describe('API Tests', () => {
  let productId;

  test('should add a product via API', async ({ request }) => {
    const newProduct = await request.post(`${baseURL}/products`, {
      data: {
        name: 'Test Product',
        price: 9.99,
      },
    });
    expect(newProduct.ok()).toBeTruthy();
    const productData = await newProduct.json();
    productId = productData.id;
  });

  test('should get a product by ID via API', async ({ request }) => {
    const product = await request.get(`${baseURL}/products/${productId}`);
    expect(product.ok()).toBeTruthy();
    const productData = await product.json();
    expect(productData).toHaveProperty('name', 'Test Product');
    expect(productData).toHaveProperty('price', 9.99);
  });

  test('should update a product via API', async ({ request }) => {
    const updatedProduct = await request.put(`${baseURL}/products/${productId}`, {
      data: {
        name: 'Updated Product',
        price: 19.99,
      },
    });
    expect(updatedProduct.ok()).toBeTruthy();
  });

  test('should delete a product via API', async ({ request }) => {
    const deleteResponse = await request.delete(`${baseURL}/products/${productId}`);
    expect(deleteResponse.ok()).toBeTruthy();
  });
});
