import { test, expect } from '@playwright/test';
import { MongoClient } from 'mongodb';

// MongoDB connection setup
const baseURL = process.env.BASE_URL;
const API_URL = process.env.API_URL;
const MONGO_DB_NAME = process.env.MONGO_DB_NAME;
const MONGO_IP = process.env.MONGO_IP;
const MONGO_PORT = process.env.MONGO_PORT;

const uri = `mongodb://${MONGO_IP}:${MONGO_PORT}/`;
 // replace with your MongoDB connection string
const client = new MongoClient(uri);
const dbName = MONGO_DB_NAME; // replace with your database name
const collectionName = 'users'; // replace with your collection name

// Helper function to delete user


test('should add a user via API and verify', async ({ request }) => {
    // Create a new user
    const newUserResponse = await request.post(`${API_URL}/users`, {
      data: {
        name: 'A V Nagireddy1111111',
        email: 'test@example.com1111111',
      },
    });
    expect(newUserResponse.status()).toBe(200);
    const newUser = await newUserResponse.json();
    expect(newUser).toHaveProperty('name', 'A V Nagireddy1111111');
    expect(newUser).toHaveProperty('email', 'test@example.com1111111');
  });

test('should add a user via WEB APP and verify DUPLICATE', async ({ page }) => {
  await page.goto(`${baseURL}/add`);
  await page.fill('input[name="name"]', 'A V Nagireddy1111111');
  await page.fill('input[name="email"]', 'test@example.com1111111');
  await page.click('button[type="submit"]');
  await expect(page.getByRole('alert')).toContainText('Failed to add user. Please try again.');

  // Delete the user if it was somehow added
  
});
test('delete user from db', async ({ request }) => {
    const email="test@example.com1111111"
    try {
    await client.connect();
    const database = client.db(dbName);
    const collection = database.collection(collectionName);
    const result = await collection.deleteOne({ email: email });
    console.log(`Deleted ${result.deletedCount} user(s) with email: ${email}`);
     expect(result.deletedCount).toBe(1);
  } finally {
    await client.close();
  }
});


