#!/bin/bash
. common_script.sh
cat common_script.sh > vpl_execution
cp -r /usr/local/customlibs/test .
cp app.spec.ts test/tests/app.spec.ts

# Extract data from url.xml
app_url=$(grep -oP '(?<=<url value=")[^"]*(?=")' url.xml)
api_url=$(grep -oP '(?<=<apiurl value=")[^"]*(?=")' url.xml)
mongo_ip=$(grep -oP '(?<=<dbhost value=")[^"]*(?=")' url.xml)
mongo_port=$(grep -oP '(?<=<dbport value=")[^"]*(?=")' url.xml)
mongo_db_name=$(grep -oP '(?<=<dbname value=")[^"]*(?=")' url.xml)

# Check if the data was successfully extracted
if [ -z "$app_url" ] || [ -z "$api_url" ] || [ -z "$mongo_ip" ] || [ -z "$mongo_port" ] || [ -z "$mongo_db_name" ]; then
    echo "Failed to extract all necessary data from url.xml"
    exit 1
fi

# Print the extracted data for debugging
# echo "Extracted Application URL: $app_url"
# echo "Extracted API URL: $api_url"
# echo "Extracted MongoDB IP: $mongo_ip"
# echo "Extracted MongoDB Port: $mongo_port"
# echo "Extracted MongoDB Database Name: $mongo_db_name"

# Construct the command with the extracted data
echo "cd test && PLAYWRIGHT_BROWSERS_PATH=/usr/local/customlibs/.cache/ms-playwright BASE_URL=$app_url API_URL=$api_url MONGO_IP=$mongo_ip MONGO_PORT=$mongo_port MONGO_DB_NAME=$mongo_db_name npx playwright test tests/app.spec.ts" > vpl_execution
chmod +x vpl_execution
